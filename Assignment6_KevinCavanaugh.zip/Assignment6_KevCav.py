# -------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   RRoot
# Date:  July 16, 2012
# ChangeLog: (Who, When, What)
#   RRoot, 11/02/2016, Created starting template
#   <Kevin Cavanaugh>, 08/12/18, Added code to complete assignment 5
#   <Kevin Cavanaugh>, 08/20/18, Created functions grouped into a class to complete assignment 6
# https://www.tutorialspoint.com/python/python_dictionary.htm
# -------------------------------------------------#

# -- Data --#
# declare variables and constants
# objFile = An object that represents a file
# strData = A row of text data from the file
# dicRow = A row of data separated into elements of a dictionary {Task,Priority}
# lstTable = A dictionary that acts as a 'table' of rows
# strMenu = A menu of user options
# strChoice = Capture the user option selection

#-- Input/Output --#
# User can see a Menu (Step 2)
# User can see data (Step 3)
# User can insert or delete data(Step 4 and 5)
# User can save to file (Step 6)

#-- Processing --#
# Step 1
# When the program starts, load the any data you have
# in a text file called ToDo.txt into a python Dictionary.

# Step 2
# Display a menu of choices to the user

# Step 3
# Display all todo items to user

# Step 4
# Add a new item to the list/Table

# Step 5
# Remove a new item to the list/Table

# Step 6
# Save tasks to the ToDo.txt file
# and exits the program

# -------------------------------


# Assignment 6: Step 6 - Create class to hold functions
class ToDo:

    # Assignment 6: Step 1 - Create a function that loads each row of data in "ToDo.txt"
    #                        into a python Dictionary and adds it to a python list
    @staticmethod
    def LoadRows(file = "ToDo.txt"):
        objFileName = open(file, "r")
        strData = objFileName.readline()
        strData = strData.lower()
        dicRow = {"Task": strData.split(',')[0].strip(), "Priority": strData.split(',')[1].strip()}
        lstTable = [dicRow]
        for line in objFileName:
            strData = line.lower()
            dicRow = {"Task": strData.split(',')[0].strip(), "Priority": strData.split(',')[1].strip()}
            lstTable += [dicRow]
        return lstTable

    # Assignment 6: Step 2 - Create a function that displays contents of list to user
    @staticmethod
    def DisplayList(lstTable):
        for line in lstTable:
            print(line)
        print()
        input("Press enter to continue.")

    # Assignment 6: Step 3 - Create a function that allows the user to add a task
    @staticmethod
    def AddTask(lstTable):
        strTask = input("Enter Task: ")
        strPriority = input("Enter Priority: ")
        dicRow = {"Task": strTask.lower(), "Priority": strPriority.lower()}
        lstTable += [dicRow]
        print()
        input("Press enter to continue.")
        return lstTable

    # Assignment 7: Step 4 - Create a function that allows the user to remove a task
    @staticmethod
    def DeleteTask(lstTable):
        try:
            strDelete = input("Task to delete: ")
            strDeletePriority = input("Please input the tasks' priority: ")
            dicDeleteRow = {"Task": strDelete.lower(), "Priority": strDeletePriority.lower()}
            lstTable.remove(dicDeleteRow)
            print("The following data has been deleted:\n", dicDeleteRow, "\n")
            input("Press enter to continue.")
            return lstTable
        except:
            input("Task not recognized.  Press enter to continue.")

    # Assignment 6: Step 5 - Create a function that saves the data from the table into the "ToDo.txt"
    #                        and exits the program
    @staticmethod
    def SaveAndExit(lstTable):
        objFileName = open("ToDo.txt", "w")
        for line in lstTable:
            objFileName.write(str(line["Task"]) + "," + str(line["Priority"]) + "\n")
        objFileName.close()
        print("The following data has been saved to the file:\n")
        for line in lstTable:
            print(str(line["Task"]) + "," + str(line["Priority"]) + "\n")
        pass

# Assignment 5: Step 1 - Load data from a file
# When the program starts, load each "row" of data
# in "ToDo.txt" into a python Dictionary.
# Add the each dictionary "row" to a python list "table"

input("Press enter to load ToDo list.")
lstTable = ToDo.LoadRows()

# Assignment 5: Step 2 - Display a menu of choices to the user
while (True):
    print("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File and Exit the Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 5]: "))
    print()  # adding a new line

    # Assignment 5: Step 3 -Show the current items in the table

    if (strChoice.strip() == '1'):
        ToDo.DisplayList(lstTable)

    # Assignment 5: Step 4 - Add a new item to the list/Table
    elif (strChoice.strip() == '2'):
        ToDo.AddTask(lstTable)

    # Assignment 5: Step 5 - Remove an existing item from the list/Table
    elif (strChoice == '3'):
        ToDo.DeleteTask(lstTable)

    # Assignment 5: Step 6 - Save tasks to the "ToDo.txt"
    # and Exits the Program
    elif (strChoice == '4'):
        ToDo.SaveAndExit(lstTable)
        break

    else:
        input("Unrecognized input.  Press enter and select a valid input.")

input("Press enter to exit the program.")
