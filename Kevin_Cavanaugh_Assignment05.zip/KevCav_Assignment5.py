# -------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   RRoot
# Date:  July 16, 2012
# ChangeLog: (Who, When, What)
#   RRoot, 11/02/2016, Created starting template
#   <Kevin Cavanaugh>, 08/12/18, Added code to complete assignment 5
# https://www.tutorialspoint.com/python/python_dictionary.htm
# -------------------------------------------------#

# -- Data --#
# declare variables and constants
# objFile = An object that represents a file
# strData = A row of text data from the file
# dicRow = A row of data separated into elements of a dictionary {Task,Priority}
# lstTable = A dictionary that acts as a 'table' of rows
# strMenu = A menu of user options
# strChoice = Capture the user option selection

# -- Input/Output --#
# User can see a Menu (Step 2)
# User can see data (Step 3)
# User can insert or delete data(Step 4 and 5)
# User can save to file (Step 6)

# -- Processing --#
# Step 1
# When the program starts, load the any data you have
# in a text file called ToDo.txt into a python Dictionary.

# Step 2
# Display a menu of choices to the user

# Step 3
# Display all todo items to user

# Step 4
# Add a new item to the list/Table

# Step 5
# Remove a new item to the list/Table

# Step 6
# Save tasks to the ToDo.txt file

# Step 7
# Exit program
# -------------------------------

# Step 1 - Load data from a file
# When the program starts, load each "row" of data
# in "ToDo.txt" into a python Dictionary.
# Add the each dictionary "row" to a python list "table"

objFileName = open("C:\_PythonClass\Assignment5\Assignment5\Todo.txt", "r")
strData = objFileName.readline()
strData = strData.lower()
dicRow = {"Task": strData.split(',')[0].strip(), "Priority": strData.split(',')[1].strip()}
lstTable = [dicRow]
for line in objFileName:
    strData = line.lower()
    dicRow = {"Task": strData.split(',')[0].strip(), "Priority": strData.split(',')[1].strip()}
    lstTable += [dicRow]

# Step 2 - Display a menu of choices to the user
while (True):
    print("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 5]: "))
    print()  # adding a new line

    # Step 3 -Show the current items in the table
    if (strChoice.strip() == '1'):
        for line in lstTable:
            print(line)
        print()
        input("Press enter to continue.")

    # Step 4 - Add a new item to the list/Table
    elif (strChoice.strip() == '2'):
        strTask = input("Enter Task: ")
        strPriority = input("Enter Priority: ")
        dicRow = {"Task": strTask.lower(), "Priority": strPriority.lower()}
        lstTable += [dicRow]
        print()
        input("Press enter to continue.")

    # Step 5 - Remove an existing item from the list/Table
    elif (strChoice == '3'):
        try:
            strDelete = input("Task to delete: ")
            strDeletePriority = input("Please input the tasks' priority: ")
            dicDeleteRow = {"Task": strDelete.lower(), "Priority": strDeletePriority.lower()}
            lstTable.remove(dicDeleteRow)
            print("The following data has been deleted:\n", dicDeleteRow, "\n")
            input("Press enter to continue.")
        except:
            strDelete2 = input("Task not recognized.  Press enter to continue.")

    # Step 6 - Save tasks to the ToDo.txt file
    elif (strChoice == '4'):
        objFileName = open("C:\_PythonClass\Assignment5\Assignment5\Todo.txt", "w")
        for line in lstTable:
            objFileName.write(str(line["Task"]) + "," + str(line["Priority"]) + "\n")
        objFileName.close()
        print("The following data has been saved to the file:\n")
        for line in lstTable:
            print(str(line["Task"]) + "," + str(line["Priority"]) + "\n")
        input("\nPress enter to continue: ")

    # Step 7 - Exit the Program
    elif (strChoice == '5'):
        break  # and Exit the program
    else:
        input("Unrecognized input.  Press enter and select a valid input.")

input("Press enter to exit the program.")
